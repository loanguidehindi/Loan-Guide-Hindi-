
(function(){
"use strict";
function inr(n){return Number.isFinite(n)?"₹"+Math.round(n).toLocaleString("en-IN"):"₹0";}
function calculateEMI(P,R,M){
  if(!Number.isFinite(P)||P<=0||!Number.isFinite(M)||M<=0)return NaN;
  var r=R/1200;
  if(r===0)return P/M;
  var f=Math.pow(1+r,M);
  return P*r*f/(f-1);
}
function showResult(P,R,M,ids){
  var emi=calculateEMI(P,R,M), total=emi*M, interest=Math.max(0,total-P);
  var e=document.getElementById(ids.emi),i=document.getElementById(ids.int),t=document.getElementById(ids.tot);
  if(!e||!i||!t)return;
  e.textContent=inr(emi);i.textContent=inr(interest);t.textContent=inr(total);
  var pe=document.getElementById(ids.p),ie=document.getElementById(ids.i);
  if(pe&&ie){var pp=total>0?Math.max(0,Math.min(100,P/total*100)):0;pe.style.width=pp+"%";ie.style.width=(100-pp)+"%";}
}
function initHero(){
  var a=document.getElementById("h-amt"),r=document.getElementById("h-rate"),m=document.getElementById("h-mon");
  if(!a||!r||!m)return;
  function update(){
    var P=parseFloat(a.value),R=parseFloat(r.value),M=parseInt(m.value,10);
    var oa=document.getElementById("o-amt"),or=document.getElementById("o-rate"),om=document.getElementById("o-mon");
    if(oa)oa.textContent=inr(P); if(or)or.textContent=R+"%"; if(om)om.textContent=M+" महीने";
    showResult(P,R,M,{emi:"h-emi",int:"h-int",tot:"h-tot",p:"h-p",i:"h-i"});
  }
  [a,r,m].forEach(function(x){x.addEventListener("input",update);x.addEventListener("change",update);}); update();
}
function initCalc(){
  var f=document.getElementById("emiForm");if(!f)return;
  var a=document.getElementById("c-amt"),r=document.getElementById("c-rate"),ten=document.getElementById("c-ten"),unit=document.getElementById("c-unit"),err=document.getElementById("c-err"),res=document.getElementById("c-res");
  function error(msg){err.textContent=msg||"";res.hidden=!!msg;}
  f.addEventListener("submit",function(ev){
    ev.preventDefault();
    var P=parseFloat(a.value),R=parseFloat(r.value),T=parseFloat(ten.value);
    if(!Number.isFinite(P)||P<=0){error("कृपया loan की रकम 0 से ज्यादा भरें।");a.focus();return;}
    if(!Number.isFinite(R)||R<0||R>100){error("कृपया ब्याज दर 0 से 100 प्रतिशत के बीच भरें।");r.focus();return;}
    if(!Number.isFinite(T)||T<=0){error("कृपया अवधि 0 से ज्यादा भरें।");ten.focus();return;}
    var M=unit.value==="years"?T*12:T;
    if(!Number.isFinite(M)||M<1||M>1200){error("कृपया अवधि सही भरें। अधिकतम 100 साल तक की अवधि मान्य है।");ten.focus();return;}
    M=Math.round(M);err.textContent="";res.hidden=false;
    showResult(P,R,M,{emi:"c-emi",int:"c-int",tot:"c-tot",p:"c-p",i:"c-i"});
  });
}
function init(){initHero();initCalc();}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
