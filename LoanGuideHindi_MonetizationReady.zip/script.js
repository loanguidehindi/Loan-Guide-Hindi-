
function calculateEMI(){
 const p=Number(document.getElementById('principal').value)||0;
 const annual=Number(document.getElementById('rate').value)||0;
 const n=Number(document.getElementById('months').value)||0;
 if(!p||!n){document.getElementById('emi').textContent='कृपया सही राशि और अवधि भरें।';return}
 const r=annual/12/100;
 const emi=r===0?p/n:p*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);
 const total=emi*n;
 document.getElementById('emi').innerHTML=`मासिक EMI: ₹${emi.toLocaleString('en-IN',{maximumFractionDigits:0})}<br><small>कुल भुगतान: ₹${total.toLocaleString('en-IN',{maximumFractionDigits:0})}</small>`;
}
