(function () {
  "use strict";

  function inr(n) {
    if (!Number.isFinite(n)) return "₹0";
    return "₹" + Math.round(n).toLocaleString("en-IN");
  }

  function calculateEMI(principal, annualRate, months) {
    var monthlyRate = annualRate / 1200;
    if (monthlyRate === 0) return principal / months;

    var factor = Math.pow(1 + monthlyRate, months);
    return principal * monthlyRate * factor / (factor - 1);
  }

  function showResult(principal, annualRate, months, ids) {
    var monthlyEMI = calculateEMI(principal, annualRate, months);
    var totalPayment = monthlyEMI * months;
    var totalInterest = Math.max(0, totalPayment - principal);

    var emiEl = document.getElementById(ids.emi);
    var intEl = document.getElementById(ids.int);
    var totEl = document.getElementById(ids.tot);

    if (!emiEl || !intEl || !totEl) return;

    emiEl.textContent = inr(monthlyEMI);
    intEl.textContent = inr(totalInterest);
    totEl.textContent = inr(totalPayment);

    var pEl = document.getElementById(ids.p);
    var iEl = document.getElementById(ids.i);

    if (pEl && iEl) {
      var principalPercent = totalPayment > 0
        ? Math.max(0, Math.min(100, principal / totalPayment * 100))
        : 0;

      pEl.style.width = principalPercent + "%";
      iEl.style.width = (100 - principalPercent) + "%";
    }
  }

  function initHeroCalculator() {
    var amount = document.getElementById("h-amt");
    var rate = document.getElementById("h-rate");
    var months = document.getElementById("h-mon");

    if (!amount || !rate || !months) return;

    var ids = { emi: "h-emi", int: "h-int", tot: "h-tot", p: "h-p", i: "h-i" };

    function update() {
      var P = parseFloat(amount.value);
      var R = parseFloat(rate.value);
      var M = parseInt(months.value, 10);

      var oAmt = document.getElementById("o-amt");
      var oRate = document.getElementById("o-rate");
      var oMon = document.getElementById("o-mon");

      if (oAmt) oAmt.textContent = Number.isFinite(P) ? inr(P) : "₹0";
      if (oRate) oRate.textContent = Number.isFinite(R) ? R + "%" : "0%";
      if (oMon) oMon.textContent = Number.isFinite(M) ? M + " महीने" : "0 महीने";

      if (P > 0 && R >= 0 && R <= 100 && M >= 1) {
        showResult(P, R, M, ids);
      }
    }

    [amount, rate, months].forEach(function (el) {
      el.addEventListener("input", update);
      el.addEventListener("change", update);
    });

    update();
  }

  function initEMICalculator() {
    var form = document.getElementById("emiForm");
    if (!form) return;

    var amount = document.getElementById("c-amt");
    var rate = document.getElementById("c-rate");
    var tenure = document.getElementById("c-ten");
    var unit = document.getElementById("c-unit");
    var error = document.getElementById("c-err");
    var result = document.getElementById("c-res");

    if (!amount || !rate || !tenure || !unit || !error || !result) return;

    var ids = { emi: "c-emi", int: "c-int", tot: "c-tot", p: "c-p", i: "c-i" };

    function setError(message) {
      error.textContent = message || "";
      result.hidden = !!message;
    }

    form.addEventListener("submit", function (event) {
      event.preventDefault();

      var P = parseFloat(amount.value);
      var R = parseFloat(rate.value);
      var enteredTenure = parseFloat(tenure.value);

      if (!Number.isFinite(P) || P <= 0) {
        setError("कृपया loan की रकम 0 से ज्यादा भरें।");
        amount.focus();
        return;
      }

      if (!Number.isFinite(R) || R < 0 || R > 100) {
        setError("कृपया ब्याज दर 0 से 100 प्रतिशत के बीच भरें।");
        rate.focus();
        return;
      }

      if (!Number.isFinite(enteredTenure) || enteredTenure <= 0) {
        setError("कृपया loan की अवधि 0 से ज्यादा भरें।");
        tenure.focus();
        return;
      }

      var months = unit.value === "years" ? enteredTenure * 12 : enteredTenure;

      if (!Number.isFinite(months) || months < 1 || months > 1200) {
        setError("कृपया अवधि सही भरें। अधिकतम 100 साल तक की अवधि मान्य है।");
        tenure.focus();
        return;
      }

      months = Math.round(months);
      error.textContent = "";
      result.hidden = false;
      showResult(P, R, months, ids);
    });

    [amount, rate, tenure].forEach(function (el) {
      el.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
          event.preventDefault();
          if (form.requestSubmit) form.requestSubmit();
          else form.dispatchEvent(new Event("submit", { cancelable: true }));
        }
      });
    });
  }

  function init() {
    initHeroCalculator();
    initEMICalculator();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
