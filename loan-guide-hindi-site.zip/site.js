(function(){
  function inr(n){return '\u20B9'+Math.round(n).toLocaleString('en-IN');}
  function emi(P,a,n){var r=a/1200;if(r===0)return P/n;var f=Math.pow(1+r,n);return P*r*f/(f-1);}
  function show(P,a,n,ids){
    var e=emi(P,a,n),tot=e*n,intr=tot-P;
    document.getElementById(ids.emi).textContent=inr(e);
    document.getElementById(ids.int).textContent=inr(intr);
    document.getElementById(ids.tot).textContent=inr(tot);
    var pp=Math.max(0,Math.min(100,P/tot*100));
    document.getElementById(ids.p).style.width=pp+'%';
    document.getElementById(ids.i).style.width=(100-pp)+'%';
  }
  var hero=document.getElementById('h-amt');
  if(hero){
    var A=hero,R=document.getElementById('h-rate'),M=document.getElementById('h-mon');
    var ids={emi:'h-emi',int:'h-int',tot:'h-tot',p:'h-p',i:'h-i'};
    function upd(){
      document.getElementById('o-amt').textContent=inr(+A.value);
      document.getElementById('o-rate').textContent=(+R.value)+'%';
      document.getElementById('o-mon').textContent=M.value+' महीने';
      show(+A.value,+R.value,+M.value,ids);
    }
    [A,R,M].forEach(function(el){el.addEventListener('input',upd);});
    upd();
  }
  var form=document.getElementById('emiForm');
  if(form){
    var ids2={emi:'c-emi',int:'c-int',tot:'c-tot',p:'c-p',i:'c-i'};
    form.addEventListener('submit',function(ev){
      ev.preventDefault();
      var P=parseFloat(document.getElementById('c-amt').value),
          a=parseFloat(document.getElementById('c-rate').value),
          n=parseFloat(document.getElementById('c-ten').value),
          u=document.getElementById('c-unit').value,
          err=document.getElementById('c-err'),res=document.getElementById('c-res');
      if(u==='years')n=n*12;
      if(!(P>0)||!(a>=0)||!(n>=1)){err.textContent='कृपया loan की रकम, ब्याज दर और अवधि सही भरें (रकम और अवधि 0 से ज्यादा होनी चाहिए)।';res.hidden=true;return;}
      if(a>100){err.textContent='ब्याज दर 100 प्रतिशत से ज्यादा नहीं हो सकती।';res.hidden=true;return;}
      err.textContent='';res.hidden=false;
      show(P,a,Math.round(n),ids2);
    });
  }
})();
